
package com.example.studentlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity2 extends AppCompatActivity {
Button backbutton,subbut2;
EditText name1,usn1,password1;
DBhelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        backbutton=findViewById(R.id.back);
        subbut2=findViewById(R.id.submit);
        name1=findViewById(R.id.name);
        usn1=findViewById(R.id.usn);
        password1=findViewById(R.id.Password);

        db = new DBhelper(this);

      subbut2.setOnClickListener(new View.OnClickListener(){
          @Override
          public void onClick(View view) {

              String nameTXT = name1.getText().toString();
              String usnTXT = usn1.getText().toString();
              String passTXT = password1.getText().toString();

              boolean checkinsertdata = db.insertuserdata(nameTXT,usnTXT,passTXT);
              if(checkinsertdata == true)
                  Toast.makeText(MainActivity2.this,"New Entery Inserted", Toast.LENGTH_LONG).show();
              else
                  Toast.makeText(MainActivity2.this,"New Entry Not Inserted",Toast.LENGTH_SHORT).show();
          }


          }
      );

        backbutton.setOnClickListener(new View.OnClickListener()
                                      {
                                          @Override
                                          public void onClick(View v) {
                                              finish();
                                          }
                                      }


        );

}
}