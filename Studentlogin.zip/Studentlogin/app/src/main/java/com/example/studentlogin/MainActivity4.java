package com.example.studentlogin;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;

import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity4 extends AppCompatActivity {
Button insertt,updatte,delette,displayy;
    DBhelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        insertt=findViewById(R.id.insert);
        updatte=findViewById(R.id.update);
        delette=findViewById(R.id.delete);
        displayy=findViewById(R.id.display);
        db= new DBhelper(this);


        insertt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities3();
            }

        });

        updatte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities4();
            }

        });


        delette.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchActivities4();
            }

        });

        displayy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = db.getdata();
                if(((Cursor) res).getCount()==0){
                    Toast.makeText(getApplicationContext(), "No Entry Exists", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext()){
                    buffer.append("Name :"+res.getString(0)+"\n");
                    buffer.append("USN :"+res.getString(1)+"\n");
                    buffer.append("Password :"+res.getString(2)+"\n\n");
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity4.this);
                builder.setCancelable(true);
                builder.setTitle("User Entries");
                builder.setMessage(buffer.toString());
                builder.show();
            }
            }

        );

    }

    private void switchActivities3(){
        Intent intent2= new Intent(this,MainActivity2.class);
        startActivity(intent2);
    }

    private void switchActivities4(){
        Intent intent3= new Intent(this,MainActivity5.class);
        startActivity(intent3);
    }


}