package com.example.studentlogin;

import androidx.appcompat.app.AppCompatActivity;



import androidx.appcompat.app.AlertDialog;

import android.database.Cursor;
import android.os.Bundle;

import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity5 extends AppCompatActivity {
    DBhelper db;
    EditText USN,NAME,PASSWORD,USN1;
    Button Update,Delete;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        Update=findViewById(R.id.update1);
        Delete=findViewById(R.id.delete1);
        USN=findViewById(R.id.usn1);
        USN1=findViewById(R.id.usn2);
        NAME=findViewById(R.id.name2);
        PASSWORD=findViewById(R.id.password2);
        db= new DBhelper(this);

        Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String nameTXT = NAME.getText().toString();
                String usnTXT = USN.getText().toString();
                String usnTXT1 = USN1.getText().toString();
                String pasTXT = PASSWORD.getText().toString();
                Boolean checker = db.updateuserdata(nameTXT,usnTXT,usnTXT1, pasTXT);
                if(checker==true)
                    Toast.makeText(getApplicationContext(), "Entry Updated", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(getApplicationContext(), "New Entry Not Updated", Toast.LENGTH_SHORT).show();

            }

        });


        Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String usnTXT = USN.getText().toString();
                Boolean checkudeletedata = db.deletedata(usnTXT);
                if(usnTXT.equals("")) {
                    Toast.makeText(getApplicationContext(), "Dont Let USN Empty", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (checkudeletedata == true)
                        Toast.makeText(getApplicationContext(), "Entry Deleted", Toast.LENGTH_SHORT).show();
                    else
                        Toast.makeText(getApplicationContext(), "Entry Not Deleted", Toast.LENGTH_SHORT).show();
                }

            }

        });


    }
}