package com.example.studentlogin;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteException;


public class DBhelper extends SQLiteOpenHelper{

    public DBhelper(Context context) {
        super(context, "student_details.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table student_details(name TEXT , usn TEXT primary key, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop Table if exists student_details");

    }

    public Boolean insertuserdata(String name, String usn, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("usn", usn);
        contentValues.put("password", password);
        long result = db.insert("student_details", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
    public Boolean checkusn(String usn) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from student_details where usn = ?", new String[]{usn});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    public Boolean checkusnpassword(String usn, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from student_details where usn = ? and password = ?", new String[] {usn,password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }


    public Boolean updateuserdata(String name, String usn, String usn1, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("usn", usn1);
        contentValues.put("password", password);
        Cursor cursor = db.rawQuery("Select * from student_details where usn = ?", new String[]{usn});
        if (cursor.getCount() > 0) {
            long result = db.update("student_details", contentValues, "usn=?", new String[]{usn});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }
        else {
            return false;
        }
    }

    public Boolean deletedata (String usn)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from student_details where usn = ?", new String[]{usn});
        if (cursor.getCount() > 0) {
            long result = db.delete("student_details", "usn=?", new String[]{usn});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }

    }


    public Cursor getdata ()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from student_details", null);
        return cursor;

    }


}