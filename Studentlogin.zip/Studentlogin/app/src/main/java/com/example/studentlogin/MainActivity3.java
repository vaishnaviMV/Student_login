package com.example.studentlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {
Button submitt;
EditText userid,password2;
DBhelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        submitt=findViewById(R.id.submit2);
        userid=findViewById(R.id.userid);
        password2=findViewById(R.id.password);
        db = new DBhelper(this);



        submitt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String Userid = userid.getText().toString();
                String Password1 = password2.getText().toString();

                if(Userid.equals("")||Password1.equals(""))
                    Toast.makeText(getApplicationContext(), "Please enter all the fields", Toast.LENGTH_SHORT).show();
                else
                {
                    Boolean checkusnpass = db.checkusnpassword(Userid, Password1);
                    if(checkusnpass==true) {
                        Toast.makeText(getApplicationContext(), "Sign in successfull", Toast.LENGTH_SHORT).show();
                        switchActivities2();
                      }
                    else{
                        Toast.makeText(getApplicationContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    }
            }

        }

        });

    }

    private void switchActivities2(){
        Intent intent1= new Intent(this,MainActivity4.class);
        startActivity(intent1);
    }

    }




